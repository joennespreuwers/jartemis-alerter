module.exports = {
   name: 'online',
   description: "Send the 'service is back online' update",
   disabled: false,
   usage: 'online',
   sprewCrewOnly: true,
   directlyPostGlobalUpdate: true,
};
