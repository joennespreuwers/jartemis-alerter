module.exports = {
   name: 'offline',
   description: "Send the 'service is offline' update",
   disabled: false,
   usage: 'offline',
   sprewCrewOnly: true,
   directlyPostGlobalUpdate: true,
};
